/****************************************************************************************/
// COPYRIGHT ANDCONFIDENTIALITYNOTICE
//
// SONY DEPTHSENSING SOLUTIONS CONFIDENTIAL INFORMATION
//
// All rights reserved to Sony Depthsensing Solutions SA/NV, a
// company incorporated and existing under the laws of Belgium, with
// its principal place of business at Boulevard de la Plainelaan 11,
// 1050 Brussels (Belgium), registered with the Crossroads bank for
// enterprises under company number 0811 784 189
//
// This file is part of vitalslib, which is proprietary
// and confidential information of Sony Depthsensing Solutions SA/NV.


// Copyright (c) 2020 Sony Depthsensing Solutions SA/NV
/****************************************************************************************/
#pragma once

#ifndef vitalslib_VERSION_INCLUDED
#define vitalslib_VERSION_INCLUDED

#define vitalslib_LIBRARY_VERSION_MAJOR 0
#define vitalslib_LIBRARY_VERSION_MINOR 1
#define vitalslib_LIBRARY_VERSION_PATCH 0
#define vitalslib_LIBRARY_VERSION_STAGE 0

#endif // vitalslib_VERSION_INCLUDED
